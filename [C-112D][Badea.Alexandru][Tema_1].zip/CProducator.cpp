#include "CProducator.h"
#include "CRegizor.h"
#include<iostream>
#include<fstream>

CProducator::CProducator()
{
}

CProducator::CProducator(std::string nume, int id):CAngajat(nume,id){}

void CProducator::setProducator(std::string nume, int id)
{
	m_nume.assign(nume);
	m_id = id;
}

void CProducator::setEfecteSpecialeDinamice()
{   //pe baza gradului de compatibilitate vom seta efecte speciale auditive si vizuale pentru toate scenele dinamice
	for (int i = 0; i <m_scenariu.getVSceneDinamice().size(); i++)
	{
		if (m_scenariu.getVSceneDinamice()[i].get_nivel_compatibilitate()< 2.5)
		{
			if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ceata)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::lapovita)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::CantecPasare);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ninsoare)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::AuroraBoreala);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ploaie)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::soare)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetePadure);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::viscol)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
		}
		else
		{
			if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ceata)
			{
			m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Tunet);
			m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ninsoare)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::lapovita)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetePadure);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Valuri);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::ploaie)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Tunet);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::soare)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::CantecPasare);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneDinamice()[i].getStareVreme() == IScena::stare_vreme::viscol)
			{
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneDinamice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
		}
	}
}  

void CProducator::setEfecteSpecialeStatice()
{ //pe baza gradului de compatibilitate vom seta efecte speciale auditive si vizuale pentru toate scenele statice
	for (int i = 0; i < m_scenariu.getVSceneStatice().size(); i++)
	{
		if (m_scenariu.getVSceneStatice()[i].get_nivel_compatibilitate() < 2.5)
		{
			if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ceata)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::lapovita)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::CantecPasare);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ninsoare)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::AuroraBoreala);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ploaie)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::soare)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetePadure);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::viscol)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
		}
		else
		{
			if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ceata)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Tunet);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ninsoare)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetMare);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::lapovita)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::SunetePadure);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Valuri);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::ploaie)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Tunet);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Fulger);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::soare)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::CantecPasare);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::RazeSoare);
			}
			else if (m_scenariu.getVSceneStatice()[i].getStareVreme() == IScena::stare_vreme::viscol)
			{
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeAuditive(CEfecte_Sonore::Vijelie);
				m_scenariu.getVSceneStatice()[i].setEfecteSpecialeVizuale(CEfecte_Vizuale::Tornade);
			}
		}
	}
}

void CProducator::write_in_file(const char* outputfile)
{   //scriem in fisierul Producator.txt toate functionalitatile sale
	//in plus fata de Regizor.txt acesta are efecte vizuale si auditive pentru fiecare scena in parte
	std::ofstream g(outputfile);
	if (g.is_open() == 0)
	{
		std::cout << "Eroare la deschiderea fisierului Producator.txt" << std::endl;
		exit(1);
	}

	for (int i = 0; i < m_scenariu.getVSceneDinamice().size(); i++)
	{
		g << "Scena " << i + 1 << " ";
		m_scenariu.getVSceneDinamice()[i].print_scene(g);
		g << "Cadrul scenei este:" << std::endl;
		g << "{";

		switch (m_scenariu.getVSceneDinamice()[i].getElemNaturale())
		{
		case(IScena::elem_naturale::arbusti):
		{
			g << "arbusti;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::buturuga):
		{
			g << "buturuge;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::copaci):
		{
			g << "copaci;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::elem_nedefinite):
		{
			g << "elemente_nedefinite;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::flori):
		{
			g << "flori;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::munte):
		{
			g << "munte;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::padure):
		{
			g << "padure;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::tufe):
		{
			g << "trufe;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneDinamice()[i].getMomentZi())
		{
		case(IScena::moment_zi::amurg):
		{
			g << "amurg;" << std::endl;
			break;
		}
		case(IScena::moment_zi::apus):
		{
			g << "apus;" << std::endl;
			break;
		}
		case(IScena::moment_zi::dimineata):
		{
			g << "dimineata;" << std::endl;
			break;
		}
		case(IScena::moment_zi::moment_zi_nedefinit):
		{
			g << "moment_zi_nedefinit;" << std::endl;
			break;
		}
		case(IScena::moment_zi::noapte):
		{
			g << "noapte;" << std::endl;
			break;
		}
		case(IScena::moment_zi::pranz):
		{
			g << "pranz;" << std::endl;
			break;
		}
		case(IScena::moment_zi::rasarit):
		{
			g << "rasarit;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneDinamice()[i].getMomentZi())
		{
		case(IScena::stare_vreme::ceata):
		{
			g << "ceata;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::lapovita):
		{
			g << "lapovita;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ninsoare):
		{
			g << "ninsoare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ploaie):
		{
			g << "ploaie;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::soare):
		{
			g << "soare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::viscol):
		{
			g << "viscol;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::vreme_nedefinita):
		{
			g << "vreme_nedefinita;" << std::endl;
			break;
		}
		}
		g << "}" << std::endl;
		g << "Gradul de compatibilitate al scenei este: " << m_scenariu.getVSceneDinamice()[i].get_nivel_compatibilitate() << std::endl;
		g << "Efectul special vizual este: " << std::endl;

		//efect vizual
		switch (m_scenariu.getVSceneDinamice()[i].getEfecteSpecialeVizuale().getEfect())
		{
		case(CEfecte_Vizuale::TipuriEfecteVizuale::AuroraBoreala):
		{
			g << "AuroraBoreala " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::efect_vizual_undefined):
		{
			g << "efect_vizual_undefined " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Fulger):
		{
			g << "Fulger " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::RazeSoare):
		{
			g << "RazaSoare" << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Tornade):
		{
			g << "Tornade" << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Valuri):
		{
			g << "Valuri" << std::endl;
			break;
		}
		}

		g << std::endl << "Efectul special auditiv este: " << std::endl;
		//efect auditiv
		switch (m_scenariu.getVSceneDinamice()[i].getEfecteSpecialeSonore().getEfect())
		{
		case(CEfecte_Sonore::TipuriEfecteAuditive::CantecPasare):
		{
			g << "Cantec Pasare" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::efect_auditiv_undefined):
		{
			g << "efect_auditiv_undefined " << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::SunetePadure):
		{
			g << "SunetPadure " << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::SunetMare):
		{
			g << "SunetMare" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::Tunet):
		{
			g << "Tunet" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::Vijelie):
		{
			g << "Vijelie" << std::endl;
			break;
		}
		}
		g << std::endl;

	}

	int k = m_scenariu.getVSceneDinamice().size();
	for (int i = 0; i < m_scenariu.getVSceneStatice().size(); i++)
	{
		g << "Scena " << k + 1 << " ";
		m_scenariu.getVSceneStatice()[i].print_scene(g);
		g << "Cadrul scenei este:" << std::endl;
		g << "{";
		switch (m_scenariu.getVSceneStatice()[i].getElemNaturale())
		{
		case(IScena::elem_naturale::arbusti):
		{
			g << "arbusti;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::buturuga):
		{
			g << "buturuge;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::copaci):
		{
			g << "copaci;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::elem_nedefinite):
		{
			g << "elemente_nedefinite;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::flori):
		{
			g << "flori;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::munte):
		{
			g << "munte;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::padure):
		{
			g << "padure;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::tufe):
		{
			g << "trufe;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneStatice()[i].getMomentZi())
		{
		case(IScena::moment_zi::amurg):
		{
			g << "amurg;" << std::endl;
			break;
		}
		case(IScena::moment_zi::apus):
		{
			g << "apus;" << std::endl;
			break;
		}
		case(IScena::moment_zi::dimineata):
		{
			g << "dimineata;" << std::endl;
			break;
		}
		case(IScena::moment_zi::moment_zi_nedefinit):
		{
			g << "moment_zi_nedefinit;" << std::endl;
			break;
		}
		case(IScena::moment_zi::noapte):
		{
			g << "noapte;" << std::endl;
			break;
		}
		case(IScena::moment_zi::pranz):
		{
			g << "pranz;" << std::endl;
			break;
		}
		case(IScena::moment_zi::rasarit):
		{
			g << "rasarit;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneStatice()[i].getMomentZi())
		{
		case(IScena::stare_vreme::ceata):
		{
			g << "ceata;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::lapovita):
		{
			g << "lapovita;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ninsoare):
		{
			g << "ninsoare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ploaie):
		{
			g << "ploaie;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::soare):
		{
			g << "soare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::viscol):
		{
			g << "viscol;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::vreme_nedefinita):
		{
			g << "vreme_nedefinita;" << std::endl;
			break;
		}
		}
		g << "}" << std::endl;
		g << "Gradul de compatibilitate al scenei este: " << m_scenariu.getVSceneStatice()[i].get_nivel_compatibilitate() << std::endl << std::endl;
		g << "Efectul special vizual este: " << std::endl;
		k++;

		//efect vizual
		switch (m_scenariu.getVSceneDinamice()[i].getEfecteSpecialeVizuale().getEfect())
		{
		case(CEfecte_Vizuale::TipuriEfecteVizuale::AuroraBoreala):
		{
			g << "AuroraBoreala " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::efect_vizual_undefined):
		{
			g << "efect_vizual_undefined " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Fulger):
		{
			g << "Fulger " << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::RazeSoare):
		{
			g << "RazaSoare" << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Tornade):
		{
			g << "Tornade" << std::endl;
			break;
		}
		case(CEfecte_Vizuale::TipuriEfecteVizuale::Valuri):
		{
			g << "Valuri" << std::endl;
			break;
		}
		}

		g << std::endl << "Efectul special auditiv este: " << std::endl;
		//efect auditiv
		switch (m_scenariu.getVSceneDinamice()[i].getEfecteSpecialeSonore().getEfect())
		{
		case(CEfecte_Sonore::TipuriEfecteAuditive::CantecPasare):
		{
			g << "Cantec Pasare" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::efect_auditiv_undefined):
		{
			g << "efect_auditiv_undefined " << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::SunetePadure):
		{
			g << "SunetPadure " << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::SunetMare):
		{
			g << "SunetMare" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::Tunet):
		{
			g << "Tunet" << std::endl;
			break;
		}
		case(CEfecte_Sonore::TipuriEfecteAuditive::Vijelie):
		{
			g << "Vijelie" << std::endl;
			break;
		}
		}
		g << std::endl;
	}

	g.close();

}

std::vector<CScena_Dinamica>& CProducator::getVSceneDinamice()
{
	return m_scenariu.getVSceneDinamice();
}

std::vector<CScena_Statica>& CProducator::getVSceneStatice()
{
	return m_scenariu.getVSceneStatice();
}

std::vector<IScena*>& CProducator::getVScene()
{
	return m_scenariu.getVScene();
}