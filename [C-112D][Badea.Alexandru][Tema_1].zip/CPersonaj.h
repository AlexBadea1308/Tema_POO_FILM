#pragma once
#include<string>
#include<vector>
class CPersonaj
{
private:
	enum type { Principal, Figurant };
	std::string m_nume;
	int m_nr_aparitii;
	type m_roll_type;
	std::vector<std::string> m_replici;

public:
	CPersonaj(std::string nume, int nr_aparitii);
	CPersonaj();
	std::string getNume();
	int getNrAparitii();
	void setNrAparitii();
	void setRollType(std::string type);
	void addReplica(std::string replica);
	int getNrReplici();
	std::string printReplica(int pos);
	std::string getype()
	{
		if (this->m_roll_type == Figurant)
			return "Figurant";
		else
			return "Principal";
	}
};

