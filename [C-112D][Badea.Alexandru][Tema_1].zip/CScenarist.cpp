#define _CRT_SECURE_NO_WARNINGS
#include "CScenarist.h"
#include<iostream>
#include<fstream>
#include<vector>
#include "CPersonaj.h"
#include "IScena.h"
#include "CScena_Statica.h"
#include "CScena_Dinamica.h"
CScenarist::CScenarist(std::string nume, int id):CAngajat(nume,id){}

void CScenarist::readFromFile(const char* filename)
{
	std::ifstream f(filename);
	if (f.is_open()==0)
	{
		std::cout << "Eroare la deschiderea fisierului!" << std::endl;
		exit(1);
	}

	std::vector<CPersonaj>take_part; //numele personajelor care iau parte la dialog
	std::string line;
	int nr_personaje = 0, counter_scene = 1;  //counter scene este pentru asigna a cata scena este in firul narativ
	f >> nr_personaje;
	char words[200];
	f.getline(words, 200);
	char* p = strtok(words," ");

	while (p != NULL)
	{
		std::string nume;
		nume.assign(p);
		CPersonaj aux(nume, 0);        // citim numele personajelor si il adaugam in vectorul creat
		m_personaje.push_back(aux);
		p = strtok(NULL, " ");
	}
	std::getline(f, line);
	while (!f.eof())
	{
		int count_dialog = 0; // numara cand avem imagine statica cate personaje vor lua parte la dialog
		if (line[0] != '-')
		{
			if (take_part.size() > 0)
				take_part.clear();
			CScena_Statica *scena_s=new CScena_Statica;// scena statica
			CScena_Statica scena_statica;
			scena_s->add_text(line);
			scena_statica.add_text(line);

			take_part = impartesteInCuvinte(m_personaje, line);  //adaugam personajele exact in ordinea in care apar in scena statica
			if (take_part.size() > 0)
			{
				for (std::vector<CPersonaj>::iterator it = take_part.begin(); it != take_part.end(); it++)
				{
					scena_s->add_personaj(*it); //adaugam in scena personajele in ordinea aparitiei
					scena_statica.add_personaj(*it);
				}
			}
			scena_s->set_position(counter_scene); //setam pozitia scenei ca sa o putem refolosi cand cu ajutorul firului narativ inseram in Director.txt
			scena_statica.set_position(counter_scene); //setam pozitia scenei ca sa o putem refolosi cand cu ajutorul firului narativ inseram in Director.txt
			m_scene.push_back(scena_s);
			m_scene_statica.push_back(scena_statica);
			std::getline(f, line);
			counter_scene++;
		}
		else
		{
			int ok = 0;
			CScena_Dinamica *scena_d=new CScena_Dinamica; //scena dinamica pentru vectorul IScena*
			CScena_Dinamica scena_dinamica; //scena dinamica pentu m_scene_dinamice

			for (int i = 0; i < take_part.size();i++)
			{
				scena_d->add_scena_dinamica(take_part[i],line);  //atribuim replicile personajului corespunzator
				scena_dinamica.add_scena_dinamica(take_part[i],line);
				getline(f,line);
				if (f.eof())
				{
					scena_d->add_scena_dinamica(take_part[i+1],line);  // caz pentru ultima linie din fisier ca sa o pot adauga in scena dinamica
					scena_dinamica.add_scena_dinamica(take_part[i+1],line);
					ok = 1;
				}
				if (ok == 1)
					break;
			}
			scena_d->set_position(counter_scene); //setam pozitia scenei ca sa o putem refolosi cand cu ajutorul firului narativ inseram in Director.txt
			scena_dinamica.set_position(counter_scene); //setam pozitia scenei ca sa o putem refolosi cand cu ajutorul firului narativ inseram in Director.txt
			m_scene.push_back(scena_d);
			m_scene_dinamice.push_back(scena_dinamica);
			take_part.clear();  // stergem vectorul de personaje care iau parte in scena dinamica pentru a putea refolosi vectorul in urmatoarea imagine statica
			counter_scene++;
		}
	}
	f.close();
}

bool CScenarist::exista_perosnaj(std::string nume, std::string line)
{
	if (line.find(nume) != std::string::npos)
	{
		return true;
	}
	return false;
}

void CScenarist::write_in_file(const char* outputfile)
{   //scriem in scenarist toate functionalitatile pe care acesta le a adus
	std::ofstream g(outputfile);
	if (g.is_open() == 0)
	{
		std::cout << "Eroare la deschiderea fisierului scenarist!" << std::endl;
		exit(1);
	}
	for (int i=0;i<m_scene.size();i++)
	{
		g << "Scena " << i + 1 << ":";
		m_scene[i]->print_scene(g);
	}


	g.close();
}

void CScenarist::setScenarist(std::string nume, int id)
{
	this->m_nume.assign(nume);
	this->m_id = id;
}

int CScenarist::getNrSceneDinamice()
{
	int size=this->m_scene_dinamice.size();
	return size;
}

int CScenarist::getNrPersonaje()
{
	return this->m_personaje.size();
}

std::vector<CPersonaj>&CScenarist::getVPersonaje()
{
	return this->m_personaje;
}

std::vector<IScena*>& CScenarist::getVScene()
{
	return m_scene;
}

std::vector<CScena_Dinamica>& CScenarist::getVSceneDinamice()
{
	return m_scene_dinamice;
}

 CScena_Dinamica& CScenarist::getVSceneDinamicePoz(int pos)
{
	return m_scene_dinamice[pos];
}

int CScenarist::searchPersonaj(std::vector<CPersonaj> personaj, std::string nume)
{
	for (int i = 0; i < personaj.size(); i++)
	{
		if (personaj[i].getNume().compare(nume) == 0)
			return i;
	}
}

std::vector<CPersonaj> CScenarist::impartesteInCuvinte(std::vector<CPersonaj> personaje, std::string line)
{       //impartim linia in cuvinte pentru a cauta personajele care vor aparea in urmatoarea scena dinmica
		std::istringstream stream(line);
		std::vector<CPersonaj> take_part;

		std::string cuvant;
		while (stream >> cuvant) 
		{
			for (std::vector<CPersonaj>::iterator it = m_personaje.begin(); it != m_personaje.end(); it++)
			{
				if (cuvant.compare(it->getNume()) == 0)
				{
					take_part.push_back(*it);
					it->setNrAparitii();
				}
			}
			
		}
		return take_part;
}

void CScenarist::sorteaza_personajele()
{   //sortam personajele in ordine descrescatoare al numarul de replici
	std::sort(m_personaje.begin(), m_personaje.end(), [](CPersonaj& a, CPersonaj& b)
		{
			return a.getNrAparitii() > b.getNrAparitii();
		});
}

void CScenarist::give_roles()
{   //asignam rolurile principale primelor 3 personaje si cele figurante personajelor ramase
	int counter = 0;
	if (m_personaje.size() <2)
	{
		std::cout << "Numar insuficient de personaje" << std::endl;
		exit(1);
	}
	for (int i = 0; i < m_personaje.size(); i++)
	{
		if (counter < 3)
		{
			m_personaje[i].setRollType("Principal");
		}
		else
		{
			m_personaje[i].setRollType("Figurant");
		}
		counter++;
	}
}

std::vector<CScena_Statica>& CScenarist::getVSceneStatice()
{
	return m_scene_statica;
}

CScenarist::CScenarist():CAngajat(){}