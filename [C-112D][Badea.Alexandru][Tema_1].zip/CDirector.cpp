#include "CDirector.h"
#include<iostream>
#include<fstream>
CDirector::CDirector()
{

}
CDirector::CDirector(std::string nume, int id):CAngajat(nume,id){}

void CDirector::set_director(std::string nume, int id)
{
	m_nume.assign(nume);
	m_id = id;
}

void CDirector::set_fir_narativ(CFir_Narativ& fir_narativ)
{
	m_fir_narativ = fir_narativ;
}

void CDirector::write_in_file(const char* outputfile)
{
	std::ofstream g(outputfile);

	if (g.is_open() == 0)
	{
		std::cout << "Eroare la deschiderea fisierului Director.txt" << std::endl;
		exit(1);
	}

	//avem 3 vectori m_scene care cuprinde in tocmai ordinea scenelor, dar are ca si minus(nu are stocate in el cadrele, gradul de compatibilitate si efectele
	// m_scene dinamice care are toate scenele dinamice si contine cadru grad de compatibilitate si efecte speciale
	// m_scene statice care are toate scenele dinamice si contine cadru grad de compatibilitate si efecte speciale
	//fiecare vector dintre ei are stocata pozitia din firul narativ al scenelor
	//parcurgem vectorul m_scene si cautam pozitia scenei in ceilalti doi vectori(m_scene_dinamice si m_scene_statice) cand o gasim afisam tot ce contine scena
	for (int i = 0; i < m_fir_narativ.getVScene().size(); i++)
	{

		for (int k = 0; k < m_fir_narativ.getVSceneStatice().size(); k++)
		{
			if (m_fir_narativ.getVScene()[i]->get_position() == m_fir_narativ.getVSceneStatice()[k].get_position())
			{
				g << "Scena " << i + 1 << " ";
				m_fir_narativ.getVSceneStatice()[k].print_scene(g);
				g << "Cadrul scenei este:" << std::endl;
				g << "{";
				switch (m_fir_narativ.getVSceneStatice()[k].getElemNaturale())
				{
				case(IScena::elem_naturale::arbusti):
				{
					g << "arbusti;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::buturuga):
				{
					g << "buturuge;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::copaci):
				{
					g << "copaci;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::elem_nedefinite):
				{
					g << "elemente_nedefinite;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::flori):
				{
					g << "flori;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::munte):
				{
					g << "munte;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::padure):
				{
					g << "padure;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::tufe):
				{
					g << "trufe;" << std::endl;
					break;
				}
				}

				switch (m_fir_narativ.getVSceneStatice()[k].getMomentZi())
				{
				case(IScena::moment_zi::amurg):
				{
					g << "amurg;" << std::endl;
					break;
				}
				case(IScena::moment_zi::apus):
				{
					g << "apus;" << std::endl;
					break;
				}
				case(IScena::moment_zi::dimineata):
				{
					g << "dimineata;" << std::endl;
					break;
				}
				case(IScena::moment_zi::moment_zi_nedefinit):
				{
					g << "moment_zi_nedefinit;" << std::endl;
					break;
				}
				case(IScena::moment_zi::noapte):
				{
					g << "noapte;" << std::endl;
					break;
				}
				case(IScena::moment_zi::pranz):
				{
					g << "pranz;" << std::endl;
					break;
				}
				case(IScena::moment_zi::rasarit):
				{
					g << "rasarit;" << std::endl;
					break;
				}
				}

				switch (m_fir_narativ.getVSceneStatice()[k].getMomentZi())
				{
				case(IScena::stare_vreme::ceata):
				{
					g << "ceata;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::lapovita):
				{
					g << "lapovita;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::ninsoare):
				{
					g << "ninsoare;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::ploaie):
				{
					g << "ploaie;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::soare):
				{
					g << "soare;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::viscol):
				{
					g << "viscol;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::vreme_nedefinita):
				{
					g << "vreme_nedefinita;" << std::endl;
					break;
				}
				}
				g << "}" << std::endl;
				g << "Gradul de compatibilitate al scenei este: " << m_fir_narativ.getVSceneStatice()[k].get_nivel_compatibilitate() << std::endl << std::endl;
				g << "Efectul special vizual este: " << std::endl;
				//efect vizual
				switch (m_fir_narativ.getVSceneStatice()[k].getEfecteSpecialeVizuale().getEfect())
				{
				case(CEfecte_Vizuale::TipuriEfecteVizuale::AuroraBoreala):
				{
					g << "AuroraBoreala " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::efect_vizual_undefined):
				{
					g << "efect_vizual_undefined " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Fulger):
				{
					g << "Fulger " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::RazeSoare):
				{
					g << "RazaSoare" << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Tornade):
				{
					g << "Tornade" << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Valuri):
				{
					g << "Valuri" << std::endl;
					break;
				}
				}

				g << std::endl << "Efectul special auditiv este: " << std::endl;
				//efect auditiv
				switch (m_fir_narativ.getVSceneStatice()[k].getEfecteSpecialeSonore().getEfect())
				{
				case(CEfecte_Sonore::TipuriEfecteAuditive::CantecPasare):
				{
					g << "Cantec Pasare" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::efect_auditiv_undefined):
				{
					g << "efect_auditiv_undefined " << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::SunetePadure):
				{
					g << "SunetPadure " << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::SunetMare):
				{
					g << "SunetMare" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::Tunet):
				{
					g << "Tunet" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::Vijelie):
				{
					g << "Vijelie" << std::endl;
					break;
				}
				}
				g << std::endl;
			}
		}


		for (int j = 0; j < m_fir_narativ.getVSceneDinamice().size(); j++)
		{
			if (m_fir_narativ.getVScene()[i]->get_position() == m_fir_narativ.getVSceneDinamice()[j].get_position())
			{
				g << "Scena " << i + 1 << " ";
				m_fir_narativ.getVSceneDinamice()[j].print_scene(g);
				g << "Cadrul scenei este:" << std::endl;
				g << "{";

				switch (m_fir_narativ.getVSceneDinamice()[j].getElemNaturale())
				{
				case(IScena::elem_naturale::arbusti):
				{
					g << "arbusti;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::buturuga):
				{
					g << "buturuge;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::copaci):
				{
					g << "copaci;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::elem_nedefinite):
				{
					g << "elemente_nedefinite;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::flori):
				{
					g << "flori;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::munte):
				{
					g << "munte;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::padure):
				{
					g << "padure;" << std::endl;
					break;
				}
				case(IScena::elem_naturale::tufe):
				{
					g << "trufe;" << std::endl;
					break;
				}
				}

				switch (m_fir_narativ.getVSceneDinamice()[j].getMomentZi())
				{
				case(IScena::moment_zi::amurg):
				{
					g << "amurg;" << std::endl;
					break;
				}
				case(IScena::moment_zi::apus):
				{
					g << "apus;" << std::endl;
					break;
				}
				case(IScena::moment_zi::dimineata):
				{
					g << "dimineata;" << std::endl;
					break;
				}
				case(IScena::moment_zi::moment_zi_nedefinit):
				{
					g << "moment_zi_nedefinit;" << std::endl;
					break;
				}
				case(IScena::moment_zi::noapte):
				{
					g << "noapte;" << std::endl;
					break;
				}
				case(IScena::moment_zi::pranz):
				{
					g << "pranz;" << std::endl;
					break;
				}
				case(IScena::moment_zi::rasarit):
				{
					g << "rasarit;" << std::endl;
					break;
				}
				}

				switch (m_fir_narativ.getVSceneDinamice()[j].getMomentZi())
				{
				case(IScena::stare_vreme::ceata):
				{
					g << "ceata;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::lapovita):
				{
					g << "lapovita;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::ninsoare):
				{
					g << "ninsoare;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::ploaie):
				{
					g << "ploaie;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::soare):
				{
					g << "soare;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::viscol):
				{
					g << "viscol;" << std::endl;
					break;
				}
				case(IScena::stare_vreme::vreme_nedefinita):
				{
					g << "vreme_nedefinita;" << std::endl;
					break;
				}
				}
				g << "}" << std::endl;
				g << "Gradul de compatibilitate al scenei este: " << m_fir_narativ.getVSceneDinamice()[j].get_nivel_compatibilitate() << std::endl;
				g << "Efectul special vizual este: " << std::endl;

				//efect vizual
				switch (m_fir_narativ.getVSceneDinamice()[j].getEfecteSpecialeVizuale().getEfect())
				{
				case(CEfecte_Vizuale::TipuriEfecteVizuale::AuroraBoreala):
				{
					g << "AuroraBoreala " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::efect_vizual_undefined):
				{
					g << "efect_vizual_undefined " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Fulger):
				{
					g << "Fulger " << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::RazeSoare):
				{
					g << "RazaSoare" << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Tornade):
				{
					g << "Tornade" << std::endl;
					break;
				}
				case(CEfecte_Vizuale::TipuriEfecteVizuale::Valuri):
				{
					g << "Valuri" << std::endl;
					break;
				}
				}

				g << std::endl << "Efectul special auditiv este: " << std::endl;
				//efect auditiv
				switch (m_fir_narativ.getVSceneDinamice()[j].getEfecteSpecialeSonore().getEfect())
				{
				case(CEfecte_Sonore::TipuriEfecteAuditive::CantecPasare):
				{
					g << "Cantec Pasare" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::efect_auditiv_undefined):
				{
					g << "efect_auditiv_undefined " << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::SunetePadure):
				{
					g << "SunetPadure " << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::SunetMare):
				{
					g << "SunetMare" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::Tunet):
				{
					g << "Tunet" << std::endl;
					break;
				}
				case(CEfecte_Sonore::TipuriEfecteAuditive::Vijelie):
				{
					g << "Vijelie" << std::endl;
					break;
				}
				}
				g << std::endl;
			}
		}
	}
}