#pragma once
#include<string>
#include "CPersonaj.h"
class CActor
{
private:
	enum type{Principal,Figurant};
	std::string m_nume;
	float m_feeling;
	type m_actor_type;
public:
	CActor();
	void setNume(std::string nume);
	void setFelling(float feeling);
	void setActorType(std::string actor_type);
	std::string getNume();
	float getFeeling();
	std::string getActorType();
	void add_feeling();//cresteam starea de spirit a actorului
	void substarct_feeling();//scadem starea de spirit a actorului
};

