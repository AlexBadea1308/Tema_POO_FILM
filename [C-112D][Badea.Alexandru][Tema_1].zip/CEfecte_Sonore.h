#pragma once
#include "CEfecteSpeciale.h"
class CEfecte_Sonore:public CEfecteSpeciale
{
    public:
        typedef enum TipuriEfecteAuditive { efect_auditiv_undefined,SunetePadure,Tunet,Vijelie,SunetMare,CantecPasare };
        void setEfect(TipuriEfecteAuditive efect) { this->m_efect_auditiv = efect; }
        TipuriEfecteAuditive getEfect() { return this->m_efect_auditiv; }
    private:
        TipuriEfecteAuditive m_efect_auditiv;
};

