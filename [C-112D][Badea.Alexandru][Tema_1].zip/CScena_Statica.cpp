#include "CScena_Statica.h"
#include<iostream>
#include<fstream>

CScena_Statica::CScena_Statica()
{
}

void CScena_Statica::add_personaj(CPersonaj personaj)
{
	m_personaje.push_back(personaj);
}

void CScena_Statica::add_text(std::string text)
{
	m_text.assign(text);
}

void CScena_Statica::print_scene(std::ofstream& outputfile)
{
	outputfile<< " este statica" << std::endl;
	outputfile << "Personajele care iau parte la scena sunt: ";
	for (std::vector<CPersonaj>::iterator it = m_personaje.begin(); it != m_personaje.end(); it++)
	{
		outputfile<<it->getNume() << " ";																																																																																																										

	}
	outputfile<< std::endl << m_text << std::endl<<std::endl;
}

void CScena_Statica::set_elemente_cadru(elem_naturale natura, moment_zi moment, stare_vreme vreme)
{
		m_natura = natura;
		m_moment = moment;
		m_vreme = vreme;
}

void CScena_Statica::set_nivel_compatibilitate(float grad_compatibilitate)
{
	m_grad_compatibilitate = grad_compatibilitate;
}

std::vector<CPersonaj>& CScena_Statica::getVector()
{
	return m_personaje;
}

void CScena_Statica::setEfecteSpecialeVizuale(CEfecte_Vizuale::TipuriEfecteVizuale efectVizual)
{
	this->m_efectVizual.setEfect(efectVizual);
}

void CScena_Statica::setEfecteSpecialeAuditive(CEfecte_Sonore::TipuriEfecteAuditive efectAuditiv)
{
	this->m_efectAuditiv.setEfect(efectAuditiv);
}

float CScena_Statica::get_nivel_compatibilitate()
{
	return m_grad_compatibilitate;
}