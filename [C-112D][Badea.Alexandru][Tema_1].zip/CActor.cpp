#include "CActor.h"
#include<iostream>
#include<fstream>

CActor::CActor()
{
	m_feeling = 0;
}

void CActor::setNume(std::string nume)
{
	this->m_nume.assign(nume);
}

void CActor::setFelling(float felling)
{
	this->m_feeling = felling;
}

void CActor::setActorType(std::string actor_type)
{
	if (actor_type.compare("Principal") == 0)
	{
		this->m_actor_type = Principal;
	}
	else
		if (actor_type.compare("Figurant") == 0)
		{
			this->m_actor_type=Figurant;
		}
		else
		{
			std::cout << "Actorul nu este nici Pirncipal nici Figurant!" << std::endl;
			exit(1);
		}
}

std::string CActor::getNume()
{
	return this->m_nume;
}

float CActor::getFeeling()
{
	return this->m_feeling;
}

std::string CActor::getActorType()
{
	if (this->m_actor_type == Principal)
		return "Principal";
	else
		if (this->m_actor_type == Figurant)
			return "Figurant";
		else
			return "Alt tip necorespunzator";
}

void CActor::add_feeling()
{
	m_feeling = m_feeling + m_feeling * (float)(0.25);
}

void CActor::substarct_feeling()
{
	m_feeling = m_feeling - m_feeling * (float)(0.25);
}