#pragma once
#include "CScenarist.h"
#include "CRegizor.h"
#include "CProducator.h"
#include "CDirector.h"
class MTA_Studios
{
private:
	static MTA_Studios *mp_Instance;
	CScenarist m_scenarist;
	CRegizor m_regizor;
	CProducator m_producator;
	CDirector m_director;
	MTA_Studios();
	~MTA_Studios();
	MTA_Studios(const MTA_Studios& obj);
public:
	static MTA_Studios& getInstance();
	CScenarist& getScenarist();
	CRegizor& getRegizor();
	CProducator& getProducator();
	CDirector& getDirector();
};

