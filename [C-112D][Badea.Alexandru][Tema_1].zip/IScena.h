#pragma once
#include<fstream>
#include "CEfecte_Sonore.h"
#include "CEfecte_Vizuale.h"

class IScena
{
public:
	typedef enum { elem_nedefinite, copaci, arbusti, flori, tufe, buturuga, munte, padure } elem_naturale;
	typedef enum { moment_zi_nedefinit, rasarit, dimineata, pranz, amurg, noapte, apus } moment_zi;
	typedef enum { vreme_nedefinita, ploaie, ceata, soare, ninsoare, lapovita, viscol} stare_vreme;
	virtual void print_scene(std::ofstream& outputfile) = 0;
	virtual void set_elemente_cadru(elem_naturale natura, moment_zi moment, stare_vreme vreme) = 0;
	virtual float get_nivel_compatibilitate()=0;
	virtual void set_nivel_compatibilitate(float grad_compatibilitate)=0;
	elem_naturale& getElemNaturale() { return m_natura; }
	moment_zi& getMomentZi() { return m_moment;}
	stare_vreme& getStareVreme() { return m_vreme; }
	virtual void setEfecteSpecialeVizuale(CEfecte_Vizuale::TipuriEfecteVizuale efectVizual) = 0;
	virtual void setEfecteSpecialeAuditive(CEfecte_Sonore::TipuriEfecteAuditive efectAuditiv) = 0;
	CEfecte_Vizuale getEfecteSpecialeVizuale() { return m_efectVizual; }
	CEfecte_Sonore getEfecteSpecialeSonore() { return m_efectAuditiv; }
	virtual void set_position(int pos) = 0;
	virtual int get_position()=0;
protected:
	elem_naturale m_natura;
	moment_zi m_moment;
	stare_vreme m_vreme;
	CEfecte_Vizuale m_efectVizual;
	CEfecte_Sonore m_efectAuditiv;
	int m_position;
};

