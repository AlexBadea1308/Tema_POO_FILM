#pragma once
#include<string>
class CAngajat
{
protected:
	std::string m_nume;
	int m_id;

public:
	CAngajat(std::string nume, int id);
	CAngajat();
};

