#pragma once
#include "IActor.h"
class CActor_Principal: public IActor
{
};

