#pragma once
#include "CAngajat.h"
#include "CScenarist.h"
#include "CActor.h"
#include<vector>
class CRegizor: public CAngajat
{
private:
	CScenarist m_scenariu;
	std::vector < std::pair<CActor,CPersonaj>> m_roles;
public:
	CRegizor(std::string nume, int id);
	CRegizor();
	void setRegizor(std::string nume, int id);
	void giveScenariu(const CScenarist& scenariu);
	void giveRollsFromFile(const char* filename); // atribuim personajele actorilor
	void atribuie_replici(); //distribuim replicile in functie de carui actor le apartin 
	void printActori(std::ofstream &outputfile);  // functie de afisarea fiecarui actor impreuna cu toate replicile sale
	void modify_feeling(); // modific starea de spirit a actorilor in functie de rolul primit
	void copy_roles();  // copiez rolurile vectorului m_personaje din Scenarist in vectorul m_roles din Regizor :(
	void compune_cadru(); // compun cadru aleator pentru fiecare din vectorii m_scene, m_scene_dinamice, m_scene_statice
	int generateRandomNumber(int nr);// genereaza nr random pentru a extrage din enumurile folosite in cadru
	void set_gradScena_dinamica(); //setam gradele din vectorul m_scene_dinammice
	void set_gradScena_statica(); //setam gradele din vectorul m_scene_statice
	void write_in_file(const char* filename);// scriem in fisierul Regizor.txt tot ce a facut regizorul
	CScenarist& getScenariu() { return m_scenariu; }
};

