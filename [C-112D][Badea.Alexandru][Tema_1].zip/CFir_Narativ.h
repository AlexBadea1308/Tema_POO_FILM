#pragma once
#include "CProducator.h"
#include<vector>
class CFir_Narativ
{
private:
	std::vector<CScena_Dinamica> m_scene_dinamice;
	std::vector<CScena_Statica> m_scene_statice;
	std::vector<IScena*> m_scene;
	int m_nr_scene;
public:
	CFir_Narativ();
	void giveScenariu(CProducator& scenariu);
	std::vector<CScena_Dinamica>& getVSceneDinamice();
	std::vector<CScena_Statica>& getVSceneStatice();
	std::vector<IScena*>& getVScene();
};