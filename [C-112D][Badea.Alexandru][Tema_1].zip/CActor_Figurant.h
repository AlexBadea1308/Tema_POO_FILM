#pragma once
#include "IActor.h"
class CActor_Figurant:public IActor
{
};

