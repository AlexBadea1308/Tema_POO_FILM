#pragma once
#include "CEfecteSpeciale.h"
class CEfecte_Vizuale: public CEfecteSpeciale
{public:
    typedef enum TipuriEfecteVizuale { efect_vizual_undefined,Valuri,Fulger,Tornade, AuroraBoreala,RazeSoare};
    void setEfect(TipuriEfecteVizuale efect) { this->m_efect_vizual = efect; }
    TipuriEfecteVizuale getEfect() { return this->m_efect_vizual; }
private:
    TipuriEfecteVizuale m_efect_vizual;
};

