#pragma once
#include "IScena.h"
#include "CPersonaj.h"
#include<vector>
#include<utility>
#include<string>
class CScena_Dinamica :public IScena
{
private:
	std::vector<std::pair<CPersonaj, std::string>> m_personaje;
	float m_grad_compatibilitate;
public:
	CScena_Dinamica();
	void add_scena_dinamica(CPersonaj personaj,std::string replica);
	void print_scene(std::ofstream& outputfile)override;
	int getNrSceneDinamice();
	std::vector<std::pair<CPersonaj, std::string>>& getVector();
	CPersonaj& getPersonaj(std::string nume);
	std::string& getReplica(std::string nume);
	void set_elemente_cadru(elem_naturale natura, moment_zi moment, stare_vreme vreme)override;
	void set_nivel_compatibilitate(float grad_compatibilitate)override;
	float get_nivel_compatibilitate()override;
	void setEfecteSpecialeVizuale(CEfecte_Vizuale::TipuriEfecteVizuale efectVizual)override;
	void setEfecteSpecialeAuditive(CEfecte_Sonore::TipuriEfecteAuditive efectAuditiv)override;
	void set_position(int pos) { m_position = pos; }
	int get_position() { return m_position; }
};

