#include<iostream>
#include <string>
#include "MTA_Studios.h"
#include "CAngajat.h"
#include "IScena.h"
#include "CPersonaj.h"
MTA_Studios* MTA_Studios::mp_Instance = nullptr;

int main()
{
	MTA_Studios& Movie=MTA_Studios::getInstance();
	Movie.getScenarist().setScenarist("Alexandru_Pila", 55);
	Movie.getScenarist().readFromFile("Poveste.txt");
	Movie.getScenarist().write_in_file("Scenarist.txt");
	Movie.getScenarist().sorteaza_personajele();
	Movie.getScenarist().give_roles();

	Movie.getRegizor().setRegizor("Meclea_Bogdan", 13);
	Movie.getRegizor().giveScenariu(Movie.getScenarist());
	Movie.getRegizor().giveRollsFromFile("Actori.txt");
	Movie.getRegizor().atribuie_replici();
	Movie.getRegizor().copy_roles();
	Movie.getRegizor().modify_feeling();
	Movie.getRegizor().compune_cadru();
	Movie.getRegizor().set_gradScena_dinamica();
	Movie.getRegizor().set_gradScena_statica();
	Movie.getRegizor().write_in_file("Regizor.txt");

	Movie.getProducator().setProducator("Gruia_Bogdan", 66);
	Movie.getProducator().giveScenariu(Movie.getRegizor());
	Movie.getProducator().setEfecteSpecialeDinamice();
	Movie.getProducator().setEfecteSpecialeStatice();
	Movie.getProducator().write_in_file("producator.txt");

	CFir_Narativ Fir_Narativ;
	Fir_Narativ.giveScenariu(Movie.getProducator());

	Movie.getDirector().set_director("Axinescu_Valentin", 99);
	Movie.getDirector().set_fir_narativ(Fir_Narativ);
	Movie.getDirector().write_in_file("Director.txt");
	return 0;
}