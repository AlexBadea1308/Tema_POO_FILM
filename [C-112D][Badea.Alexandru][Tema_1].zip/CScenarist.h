#include "CAngajat.h"
#include<string>
#include<vector>
#include "IScena.h"
#include "CPersonaj.h"
#include "CScena_Dinamica.h"
#include<sstream>
#include<algorithm>
#include<iostream>
#include "CScena_Statica.h"
#pragma once
class CScenarist:public CAngajat
{
private:
	std::vector<IScena*> m_scene;
	std::vector<CPersonaj> m_personaje;
	std::vector<CScena_Dinamica> m_scene_dinamice;
	std::vector<CScena_Statica> m_scene_statica;
public:  
	CScenarist(std::string nume,int id);
	CScenarist();
	void readFromFile(const char* filename); //citim poveste deimitam scenele dinamice sau statice si le creem in vectorul de tip IScena*
	bool exista_perosnaj(std::string nume, std::string line); // verificam daca in linia din fisier gasim vreun personaj
	void write_in_file(const char* outputfile); // scriem in fisierul Scenarist.txt tot ce a reusit sa faca Scenaristul
	void setScenarist(std::string nume, int id);
	int getNrSceneDinamice();																																																																																																																																																																																																																																																																										
	int getNrPersonaje();
	std::vector<CPersonaj> &getVPersonaje(); // returnam pozitia primului element din vectorul de personaje (m_personaje)
	std::vector<IScena*>& getVScene(); //returnam pozitia primului element din vectorul de scene(m_scene)
	std::vector<CScena_Dinamica>& getVSceneDinamice(); //returnam pozitia primului element din vectorul de scene dinamice(m_scene_dinamice)
	CScena_Dinamica& getVSceneDinamicePoz(int pos);  //returnam elementul din pozitia pos din vectorul de scene_dinamide(m_scene_dinamice)
	int searchPersonaj(std::vector<CPersonaj> personaj, std::string nume); // cautam numele personajului in vectorul de personaje si returnam pozitia
	std::vector<CPersonaj> impartesteInCuvinte(std::vector<CPersonaj> personaje, std::string line);// impartim linia din fisier in cuvinte pentru a stoca intr un 
	                                                                              //vector de personaje numele personajelor care apar in scena statica si care
	void sorteaza_personajele();//sorteaza personajele in functie de nr de replici // in aceeasi oridne vor avea replicile in scena dinamica
	void give_roles(); // atribuie rolurile
	std::vector<CScena_Statica>& getVSceneStatice();
};

