#pragma once
#include"CAngajat.h"
#include"CEfecte_Sonore.h"
#include"CEfecte_Vizuale.h"
#include "IScena.h"
#include "CScenarist.h"
#include "CRegizor.h"
class CProducator:public CAngajat
{
private:
	CScenarist m_scenariu;
public:
	CProducator();
	CProducator(std::string nume, int id);
	void setProducator(std::string nume, int id);
	void setEfecteSpecialeDinamice();//setam efecte speciale pentru scenele dinamice
	void setEfecteSpecialeStatice();//setam efecte speciale pentru scnele statice
	void write_in_file(const char* outputfile);
	void giveScenariu(CRegizor& scenariu) { m_scenariu = scenariu.getScenariu();}
	std::vector<CScena_Dinamica>& getVSceneDinamice();
	std::vector<CScena_Statica>& getVSceneStatice();
	std::vector<IScena*>& getVScene();
};

