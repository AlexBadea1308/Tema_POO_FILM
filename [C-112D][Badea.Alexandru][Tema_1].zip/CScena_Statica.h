#pragma once
#include "IScena.h"
#include "CPersonaj.h"
#include<string>
#include<vector>
class CScena_Statica :public IScena
{
private:
	std::vector<CPersonaj> m_personaje;
	std::string m_text;
	float m_grad_compatibilitate;

public:
	CScena_Statica();
	void add_personaj(CPersonaj personaj);
	void add_text(std::string text);
	void print_scene(std::ofstream& outputfile)override;
	void set_elemente_cadru(elem_naturale natura, moment_zi moment, stare_vreme vreme)override;
	void set_nivel_compatibilitate(float grad_compatibilitate)override;
	float get_nivel_compatibilitate()override;
	std::vector<CPersonaj>& getVector();
	void setEfecteSpecialeVizuale(CEfecte_Vizuale::TipuriEfecteVizuale efectVizual)override;
	void setEfecteSpecialeAuditive(CEfecte_Sonore::TipuriEfecteAuditive efectAuditiv)override;
	void set_position(int pos) { m_position = pos;}
	int get_position() { return m_position; }
};

