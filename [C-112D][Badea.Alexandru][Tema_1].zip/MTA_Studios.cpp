#include "MTA_Studios.h"
#include<iostream>

MTA_Studios::MTA_Studios()
{

}

MTA_Studios::~MTA_Studios(){}

MTA_Studios::MTA_Studios(const MTA_Studios& obj)
{
    this->m_scenarist = obj.m_scenarist;
}

MTA_Studios& MTA_Studios::getInstance()
{
    if (mp_Instance == nullptr)
        mp_Instance = new MTA_Studios;
    return *mp_Instance;
}

CScenarist& MTA_Studios::getScenarist()
{
    return this->m_scenarist;
}

CRegizor& MTA_Studios::getRegizor()
{
    return this->m_regizor;
}

CProducator& MTA_Studios::getProducator()
{
    return m_producator;
}

CDirector& MTA_Studios::getDirector()
{
    return m_director;
}