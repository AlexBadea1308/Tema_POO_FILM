#pragma once
#include "CAngajat.h"
#include "CFir_Narativ.h";
class CDirector:public CAngajat
{private:
	CFir_Narativ m_fir_narativ;
public:
	CDirector();
	CDirector(std::string nume, int id);
	void set_director(std::string nume, int id);
	void set_fir_narativ(CFir_Narativ& fir_narativ);
	void write_in_file(const char* outputfile);
};

