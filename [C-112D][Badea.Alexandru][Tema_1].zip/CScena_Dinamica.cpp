#include "CScena_Dinamica.h"
#include<iostream>
#include<fstream>

CScena_Dinamica::CScena_Dinamica()
{
}

void CScena_Dinamica::add_scena_dinamica(CPersonaj personaj, std::string replica)
{
	m_personaje.push_back(std::make_pair(personaj, replica));
}

void CScena_Dinamica::print_scene(std::ofstream& outputfile)
{
	outputfile << " este dinamica" << std::endl;
	outputfile << "Personajele care apar in scena sunt: ";
	for (int i = 0; i < this->m_personaje.size(); i++)
	{
		outputfile << this->m_personaje[i].first.getNume() << " ";
	}

	outputfile << std::endl;

	for (int i=0;i<this->m_personaje.size();i++)
	{
		outputfile<< this->m_personaje[i].first.getNume() << ":" << this->m_personaje[i].second << std::endl;
	}
	outputfile << std::endl;
}

int CScena_Dinamica::getNrSceneDinamice()
{
	return m_personaje.size();
}

std::vector<std::pair<CPersonaj, std::string>>& CScena_Dinamica::getVector()
{
	return m_personaje;
}

CPersonaj& CScena_Dinamica::getPersonaj(std::string nume)
{
	for (auto& it : m_personaje)
	{
		if(nume.compare(it.first.getNume())==0)
			return it.first;
	}
}

std::string& CScena_Dinamica::getReplica(std::string nume)
{
	for (auto& it : m_personaje)
	{
		if (nume.compare(it.first.getNume()) == 0)
			return it.second;
	}
}

void CScena_Dinamica::set_elemente_cadru(elem_naturale natura, moment_zi moment, stare_vreme vreme)
{
	m_natura = natura;
	m_moment = moment;
	m_vreme = vreme;

}

float CScena_Dinamica::get_nivel_compatibilitate()
{
	return this->m_grad_compatibilitate;
}

void CScena_Dinamica::setEfecteSpecialeVizuale(CEfecte_Vizuale::TipuriEfecteVizuale efectVizual)
{
	this->m_efectVizual.setEfect(efectVizual);
}

void CScena_Dinamica::setEfecteSpecialeAuditive(CEfecte_Sonore::TipuriEfecteAuditive efectAuditiv)
{
	this->m_efectAuditiv.setEfect(efectAuditiv);
}

void CScena_Dinamica::set_nivel_compatibilitate(float grad_compatibilitate)
{
		m_grad_compatibilitate = grad_compatibilitate;
}