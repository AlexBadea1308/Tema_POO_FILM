#include "CFir_Narativ.h"
#include<iostream>

CFir_Narativ::CFir_Narativ()
{
}

void CFir_Narativ::giveScenariu(CProducator& scenariu)
{
	m_scene_dinamice = scenariu.getVSceneDinamice();
	m_scene_statice = scenariu.getVSceneStatice();
	m_scene = scenariu.getVScene();
	m_nr_scene = m_scene_dinamice.size()+m_scene_statice.size();
}

std::vector<CScena_Dinamica>& CFir_Narativ::getVSceneDinamice()
{
	return m_scene_dinamice;
}

std::vector<CScena_Statica>& CFir_Narativ::getVSceneStatice()
{
	return m_scene_statice;
}

std::vector<IScena*>& CFir_Narativ::getVScene()
{
	return m_scene;
}