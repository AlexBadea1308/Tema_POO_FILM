#include "CPersonaj.h"
#include<iostream>
#include<string>

CPersonaj::CPersonaj(std::string nume, int nr_aparitii):m_nume(nume),m_nr_aparitii(nr_aparitii){}

CPersonaj::CPersonaj()
{
    m_nr_aparitii = 0;
}

std::string CPersonaj::getNume()
{
    return this->m_nume;
}

int CPersonaj::getNrAparitii()
{
    return this->m_nr_aparitii;
}

void CPersonaj::setNrAparitii()
{
    this->m_nr_aparitii++;
}

void CPersonaj::setRollType(std::string type)
{
    if (type.compare("Principal") == 0)
    {
        this->m_roll_type =Principal;
    }
    else
    {
        if (type.compare("Figurant") == 0)
        {
            this->m_roll_type = Figurant;
        }
        else
        {
            std::cout << "Tip de rol necorespunzator!" << std::endl;
            exit(1);
        }
    }
}

void CPersonaj::addReplica(std::string replica)
{
    this->m_replici.push_back(replica);
}

int CPersonaj::getNrReplici()
{
    int nr_replici = this->m_replici.size();
    return nr_replici;
}

std::string CPersonaj::printReplica(int pos)
{
    if (pos > m_replici.size())
    {
        std::cout << "Depasirea memeoriei vectorului!" << std::endl;
        exit(1);
    }

    return m_replici[pos];
}