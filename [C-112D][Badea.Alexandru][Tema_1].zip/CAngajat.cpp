#include "CAngajat.h"

CAngajat::CAngajat(std::string nume, int id):m_nume(nume),m_id(id){}

CAngajat::CAngajat()
{
}

