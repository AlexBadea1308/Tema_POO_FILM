#include "CRegizor.h"
#include<iostream>
#include<fstream>
#include<random>

CRegizor::CRegizor(std::string nume, int id):CAngajat(nume,id){}

CRegizor::CRegizor()
{
}

void CRegizor::setRegizor(std::string nume, int id)
{
	this->m_nume.assign(nume);
	this->m_id = id;
}

void CRegizor::giveScenariu(const CScenarist& scenariu)
{
	this->m_scenariu = scenariu;
}

void CRegizor::giveRollsFromFile(const char* filename)
{
	std::ifstream f(filename);
	if (f.is_open() == 0)
	{
		std::cout << "Eroare la deschiderea fisierului cu actori!" << std::endl;
		exit(1);
	}

	CActor aux;
	std::string nume,roll;
	float feeling;
	for (int i = 0; i < m_scenariu.getVPersonaje().size(); i++)
	{
		f >> nume >> feeling >> roll;
		aux.setNume(nume);
		aux.setFelling(feeling);
		aux.setActorType(roll);
		m_roles.push_back(std::make_pair(aux, m_scenariu.getVPersonaje()[i]));
	}
	f.close();

	//citim datele despre actori si le atribuim rolurile din film
}

void CRegizor::printActori(std::ofstream& outputfile)
{
	
		for (int j = 0; j < m_roles.size(); j++)
		{
			outputfile<<m_roles[j].first.getNume() << " " <<m_roles[j].first.getFeeling() << " " <<m_roles[j].first.getActorType() << " ii corespunde personajul " <<m_roles[j].second.getNume() << std::endl;

			for (int k = 0; k < m_roles[j].second.getNrReplici(); k++)
			{
				outputfile<< m_roles[j].second.printReplica(k)<< std::endl;
			}
			outputfile<< std::endl;
		}

		//afisam personajele si replicile lor
}

void CRegizor::modify_feeling()
{
	for (int i = 0; i < m_roles.size(); i++)
	{
		if (m_roles[i].first.getActorType() == "Principal" && m_roles[i].second.getype() == "Figurant")
		{
			m_roles[i].first.substarct_feeling();
		}
		else //modificam starea de spirit in functie de rolul primit
		{
			if (m_roles[i].first.getActorType() == "Figurant" && m_roles[i].second.getype() == "Principal")
			{
				m_roles[i].first.add_feeling();
			}
		}
	}
}

void CRegizor::copy_roles()
{
	for(int j=0;j<m_roles.size();j++)
	{
		for (int i = 0; i < m_scenariu.getVPersonaje().size(); i++)
		{
			if (m_roles[j].second.getNume() == m_scenariu.getVPersonaje()[i].getNume())
			{
				m_roles[j].second.setRollType(m_scenariu.getVPersonaje()[i].getype());  
				break;
			}
		}
	}
	//copiez rolul fiecarui personaj din vectorul m_perosnaje din scenarist in vectorul m_roles din regizor pentru ca imi era util mai departe
}

void CRegizor::compune_cadru()
{
	for (int j = 0; j < m_scenariu.getVSceneDinamice().size(); j++)
	{
		m_scenariu.getVSceneDinamice()[j].set_elemente_cadru((IScena::elem_naturale)(generateRandomNumber(7)), (IScena::moment_zi)(generateRandomNumber(7)), (IScena::stare_vreme)(generateRandomNumber(5)));
	}
	for (int j = 0; j < m_scenariu.getVSceneStatice().size(); j++)
	{
		m_scenariu.getVSceneStatice()[j].set_elemente_cadru((IScena::elem_naturale)(generateRandomNumber(7)), (IScena::moment_zi)(generateRandomNumber(7)), (IScena::stare_vreme)(generateRandomNumber(5)));
	}

	// creez cadru pentru fiecare cadru din vectorul de m_scene_dinamice si m_scene_statice din m_scenarist
}

int CRegizor::generateRandomNumber(int nr)
{
		std::random_device rd; 
		std::mt19937 gen(rd()); 
		std::uniform_int_distribution<> dis(0, nr - 1);

		return dis(gen);
		//generam numar random pentru a extrage din enumurile pentru cadru intr-un mod random
}

void CRegizor::set_gradScena_dinamica()
{
	for (int i = 0; i < m_scenariu.getVSceneDinamice().size(); i++)
	{   
		float grad_compatibilitate=0;
		for (int j = 0; j < m_scenariu.getVSceneDinamice()[i].getVector().size(); j++)
		{
			for (int k = 0; k < m_roles.size(); k++)
			{
				if (m_scenariu.getVSceneDinamice()[i].getVector()[j].first.getNume() == m_roles[k].second.getNume())  //pentru scene dinamice
				{
					grad_compatibilitate += m_roles[k].first.getFeeling();
				}
			}
		}
		grad_compatibilitate=(grad_compatibilitate*0.5)/m_scenariu.getVSceneDinamice()[i].getVector().size();
		m_scenariu.getVSceneDinamice()[i].set_nivel_compatibilitate(grad_compatibilitate);
	}
	//calculez gradul de compatibilitate pentru fiecare din scnele dinamice
}

void CRegizor::set_gradScena_statica()
{
	for (int i = 0; i < m_scenariu.getVSceneStatice().size(); i++)
	{
		float grad_compatibilitate = 0;
		if(m_scenariu.getVSceneStatice()[i].getVector().size()>0)
		{
			for (int j = 0; j < m_scenariu.getVSceneStatice()[i].getVector().size(); j++)
			{
				for (int k = 0; k < m_roles.size(); k++)
				{
					if (m_scenariu.getVSceneStatice()[i].getVector()[j].getNume() == m_roles[k].second.getNume())  //pentru scene dinamice
					{
						grad_compatibilitate += m_roles[k].first.getFeeling();
					}
				}
			}
			grad_compatibilitate = (grad_compatibilitate * 0.5) / m_scenariu.getVSceneStatice()[i].getVector().size();
		}
		m_scenariu.getVSceneStatice()[i].set_nivel_compatibilitate(grad_compatibilitate);
	}
	//calculez gradul de compatibilitate pentru fiecare din scnele statice
}

void CRegizor::write_in_file(const char* outputfile)
{  // scriem in fisierul Regizor.txt actorii impreuna cu rolul pe care il joaca si toate replicile aferente fiecarui actor
   // scriem fiecare scena in parte la fel ca in scenarist impreuna cu cadrul specific al acesteia si gradul de compatibilitate
	std::ofstream g(outputfile);
	if (g.is_open()==0)
	{
		std::cout << "Eroare la deschiderea fisierului Regizor.txt!" << std::endl;
		exit(1);
	}


	printActori(g);
	g << std::endl;

	for (int i = 0; i < m_scenariu.getVSceneDinamice().size(); i++)
	{   
		g << "Scena " << i+1<< " ";
		m_scenariu.getVSceneDinamice()[i].print_scene(g);
		g << "Cadrul scenei este:"<<std::endl;
		g << "{";
		switch (m_scenariu.getVSceneDinamice()[i].getElemNaturale())
		{
			case(IScena::elem_naturale::arbusti):
			{
				g << "arbusti;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::buturuga):
			{
				g << "buturuge;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::copaci):
			{
				g << "copaci;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::elem_nedefinite):
			{
				g << "elemente_nedefinite;"<< std::endl;
				break;
			}
			case(IScena::elem_naturale::flori):
			{
				g << "flori;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::munte):
			{
				g << "munte;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::padure):
			{
				g << "padure;" << std::endl;
				break;
			}
			case(IScena::elem_naturale::tufe):
			{
				g << "trufe;" << std::endl;
				break;
			}
		}

		switch (m_scenariu.getVSceneDinamice()[i].getMomentZi())
		{
		case(IScena::moment_zi::amurg):
		{
			g << "amurg;" << std::endl;
			break;
		}
		case(IScena::moment_zi::apus):
		{
			g << "apus;" << std::endl;
			break;
		}
		case(IScena::moment_zi::dimineata):
		{
			g << "dimineata;" << std::endl;
			break;
		}
		case(IScena::moment_zi::moment_zi_nedefinit):
		{
			g << "moment_zi_nedefinit;" << std::endl;
			break;
		}
		case(IScena::moment_zi::noapte):
		{
			g << "noapte;" << std::endl;
			break;
		}
		case(IScena::moment_zi::pranz):
		{
			g << "pranz;" << std::endl;
			break;
		}
		case(IScena::moment_zi::rasarit):
		{
			g << "rasarit;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneDinamice()[i].getMomentZi())
		{
			case(IScena::stare_vreme::ceata):
		{
			g << "ceata;" << std::endl;
			break;
		}
			case(IScena::stare_vreme::lapovita):
		{
			g << "lapovita;" << std::endl;
			break;
		}
			case(IScena::stare_vreme::ninsoare):
		{
			g << "ninsoare;" << std::endl;
			break;
		}
			case(IScena::stare_vreme::ploaie):
		{
			g << "ploaie;" << std::endl;
			break;
		}
			case(IScena::stare_vreme::soare):
		{
			g << "soare;" << std::endl;
			break;
		}
			case(IScena::stare_vreme::viscol):
		{
			g << "viscol;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::vreme_nedefinita):
		{
			g << "vreme_nedefinita;" << std::endl;
			break;
		}
		}
		g << "}"<<std::endl;
		g<<"Gradul de compatibilitate al scenei este: " << m_scenariu.getVSceneDinamice()[i].get_nivel_compatibilitate() << std::endl<<std::endl;

	}

	int k = m_scenariu.getVSceneDinamice().size();
	for (int i = 0; i < m_scenariu.getVSceneStatice().size(); i++)
	{
		g << "Scena " << k+1<< " ";
		m_scenariu.getVSceneStatice()[i].print_scene(g);
		g << "Cadrul scenei este:" << std::endl;
		g << "{";
		switch (m_scenariu.getVSceneStatice()[i].getElemNaturale())
		{
		case(IScena::elem_naturale::arbusti):
		{
			g << "arbusti;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::buturuga):
		{
			g << "buturuge;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::copaci):
		{
			g << "copaci;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::elem_nedefinite):
		{
			g << "elemente_nedefinite;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::flori):
		{
			g << "flori;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::munte):
		{
			g << "munte;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::padure):
		{
			g << "padure;" << std::endl;
			break;
		}
		case(IScena::elem_naturale::tufe):
		{
			g << "trufe;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneStatice()[i].getMomentZi())
		{
		case(IScena::moment_zi::amurg):
		{
			g << "amurg;" << std::endl;
			break;
		}
		case(IScena::moment_zi::apus):
		{
			g << "apus;" << std::endl;
			break;
		}
		case(IScena::moment_zi::dimineata):
		{
			g << "dimineata;" << std::endl;
			break;
		}
		case(IScena::moment_zi::moment_zi_nedefinit):
		{
			g << "moment_zi_nedefinit;" << std::endl;
			break;
		}
		case(IScena::moment_zi::noapte):
		{
			g << "noapte;" << std::endl;
			break;
		}
		case(IScena::moment_zi::pranz):
		{
			g << "pranz;" << std::endl;
			break;
		}
		case(IScena::moment_zi::rasarit):
		{
			g << "rasarit;" << std::endl;
			break;
		}
		}

		switch (m_scenariu.getVSceneStatice()[i].getMomentZi())
		{
		case(IScena::stare_vreme::ceata):
		{
			g << "ceata;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::lapovita):
		{
			g << "lapovita;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ninsoare):
		{
			g << "ninsoare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::ploaie):
		{
			g << "ploaie;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::soare):
		{
			g << "soare;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::viscol):
		{
			g << "viscol;" << std::endl;
			break;
		}
		case(IScena::stare_vreme::vreme_nedefinita):
		{
			g << "vreme_nedefinita;" << std::endl;
			break;
		}
		}
		g << "}" << std::endl;
		g << "Gradul de compatibilitate al scenei este: " << m_scenariu.getVSceneStatice()[i].get_nivel_compatibilitate() << std::endl<<std::endl;
		k++;
	}

	g.close();
}

void CRegizor::atribuie_replici()
{
	//vreau sa adaug in m_roles toate replcile care apartin fiecarui personaj pentru a putea afisa perechea Actor Personaj si toate replicile pe care acesta le are
		for (int i = 0; i < m_scenariu.getVSceneDinamice().size(); i++)
		{
			for (int j = 0; j < m_scenariu.getVSceneDinamicePoz(i).getVector().size(); j++)
			{
				for (auto &pers : m_roles)
				{
					std::string str = m_scenariu.getVSceneDinamicePoz(i).getVector()[j].first.getNume();
					if (pers.second.getNume()==m_scenariu.getVSceneDinamicePoz(i).getVector()[j].first.getNume())
					{
						pers.second.addReplica(m_scenariu.getVSceneDinamicePoz(i).getReplica(pers.second.getNume()));
					}
				}
			}
		}
}