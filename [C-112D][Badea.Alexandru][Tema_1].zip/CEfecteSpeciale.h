#pragma once
class CEfecteSpeciale
{
};

